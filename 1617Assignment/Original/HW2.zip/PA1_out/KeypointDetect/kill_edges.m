

f1 = features(find(features(:,5)>0),:);
f2 = features2(find(features2(:,5)>0),:);

k1 = keys(find(features(:,5)>0),:);
k2 = keys2(find(features2(:,5)>0),:);


