

figure
imagesc(pyr{lvl});
hold on
colormap gray
plot(pts{lvl}(:,2),pts{lvl}(:,1),'g+');
